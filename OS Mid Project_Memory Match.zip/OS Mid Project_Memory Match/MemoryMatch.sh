#!/bin/bash
# Memory Match Challenge - Enhanced Version
# Authors: [Allama Anas and Fida Kainth]
# Features: Difficulty levels, leaderboard, multiplayer, randomized sequences, vs computer mode.

# ANSI Colors this will show differnet color in output of the program so that we can make the out put adorable...
GREEN='\e[92m'
RED='\e[91m'
BLUE='\e[94m'
YELLOW='\e[93m'
CYAN='\e[96m'
RESET='\e[0m'
BOLD='\e[1m'
BLINK='\e[5m'


#Text file to Save score and the generate_sequence() function to generate different sequences in game..
SCORE_FILE="leaderboard.txt"

clear
echo -e "${CYAN}${BOLD}Welcome to the Memory Match Game!${RESET}"

generate_sequence() {
  local length=$1
  sequence=$(cat /dev/urandom | tr -dc 'A-Z0-9' | fold -w $length | head -n 1)
}
#Other function as display_sequence() to show different sequences and 2nd function to get the user input so that we can start game…


display_sequence() {
  echo -e "${GREEN}${BLINK}Remember this sequence In Game : $sequence${RESET}"
  sleep $1
  clear
}

get_user_input() {
  echo -e "${BLUE}${BOLD}Enter the sequence Here Correctly :${RESET}"
  read -t 8 user_input
}

#Here is input check function that user will enter in the game and other one is for save score….

check_input() {
  if [[ "$user_input" == "$sequence" ]]; then
    echo -e "${GREEN}✔ Hurrah ! You earned 10 points...${RESET}"
    ((score+=10))
  else
    echo -e "${RED}✖ Ohoo! The correct sequence was : $sequence${RESET}"
    ((attempts--))
  fi
}

save_score() {
  echo "$player_name - $score" >> "$SCORE_FILE"
}

# this function will show the score board who is at 1st and second position in game 

show_leaderboard() {
  echo -e "${YELLOW}${BOLD}Leaderboard:${RESET}"
  sort -k3 -nr "$SCORE_FILE" | head -10
}

# generated diffent sequences to guess is here 

computer_guess() {
  local random_error=$((RANDOM % 2))
  if [[ $random_error -eq 0 ]]; then
    computer_input=$sequence
  else
    computer_input=$(echo "$sequence" | tr 'A-Z0-9' 'B-ZA1-90')
  fi
}
# user vs Computer mode function....is Here 
vs_computer_mode() {
  generate_sequence 4
  display_sequence 5
  get_user_input
  computer_guess

  echo -e "${CYAN}Your Input Is : $user_input${RESET}"
  echo -e "${YELLOW}Computer's Input Is : $computer_input${RESET}"

  if [[ "$user_input" == "$sequence" && "$computer_input" == "$sequence" ]]; then
    echo -e "${GREEN}Good It's a tie!${RESET}"
  elif [[ "$user_input" == "$sequence" ]]; then
    echo -e "${GREEN}Huraaa You win this round!${RESET}"
    ((score+=10))
  else
    echo -e "${RED} Ohh  Computer wins this round!${RESET}"
  fi
}
# this function will give user the game play mode according differnet panelties.....
choose_difficulty() {
  echo -e "${CYAN}Choose Difficulty Level:${RESET}"
  echo -e "${GREEN}1. Easy (8 sec recall)${RESET}"
  echo -e "${YELLOW}2. Medium (5 sec recall)${RESET}"
  echo -e "${RED}3. Hard (3 sec recall)${RESET}"
  read -p "Enter choice: " difficulty

  case $difficulty in
    1) recall_time=8 ;;
    2) recall_time=5 ;;
    3) recall_time=3 ;;
    *) echo -e "${RED}Invalid choice, defaulting to Medium.${RESET}"
       recall_time=5 ;;
  esac
}
# play game function here you will register your name and other related functionalities and your score, related data....

play_game() {
  attempts=3
  score=0
  read -p "Enter your Name Here : " player_name
  choose_difficulty

  while [[ $attempts -gt 0 ]]; do
    generate_sequence 4
    display_sequence $recall_time
    get_user_input
    check_input
  done
  save_score
  echo -e "${YELLOW}${BOLD}Game Over! Your final score Is : $score${RESET}"
}
# this function for to play more than one players at a time .....
multiplayer_mode() {
  read -p "Enter Player 1 Name Is: " player1
  read -p "Enter Player 2 Name Is: " player2
  p1_score=0
  p2_score=0

  for round in {1..3}; do
    echo -e "${CYAN}${BOLD}Round $round - $player1's turn${RESET}"
    generate_sequence 4
    display_sequence 5
    get_user_input
    [[ "$user_input" == "$sequence" ]] && ((p1_score+=10))

    echo -e "${CYAN}${BOLD}Round $round - $player2's turn${RESET}"
    generate_sequence 4
    display_sequence 5
    get_user_input
    [[ "$user_input" == "$sequence" ]] && ((p2_score+=10))
  done

  echo -e "${YELLOW}${BOLD}Final Scores:${RESET}"
  echo -e "${GREEN}$player1: $p1_score points${RESET}"
  echo -e "${BLUE}$player2: $p2_score points${RESET}"

  [[ $p1_score -gt $p2_score ]] && echo -e "${GREEN}$player1 Wins!${RESET}"
  [[ $p2_score -gt $p1_score ]] && echo -e "${BLUE}$player2 Wins!${RESET}"
  [[ $p1_score -eq $p2_score ]] && echo -e "${CYAN}It's a Tie!${RESET}"
}
# view point of game like Drop down menu , check point to join game on different modes .....

main_menu() {
  echo -e "${CYAN}${BOLD}Welcome to Memory Match Challenge!${RESET}"
  echo -e "${GREEN}1. Play Game${RESET}"
  echo -e "${BLUE}2. Play VS Computer${RESET}"
  echo -e "${YELLOW}3. Multiplayer Mode${RESET}"
  echo -e "${CYAN}4. View Leaderboard${RESET}"
  echo -e "${RED}5. Exit${RESET}"
  read -p "Choose an option: " choice

  case $choice in
    1) play_game ;;
    2) vs_computer_mode ;;
    3) multiplayer_mode ;;
    4) show_leaderboard ;;
    5) exit ;;
    *) echo -e "${RED}Invalid option, try again.${RESET}" ;;
  esac
}

main_menu
